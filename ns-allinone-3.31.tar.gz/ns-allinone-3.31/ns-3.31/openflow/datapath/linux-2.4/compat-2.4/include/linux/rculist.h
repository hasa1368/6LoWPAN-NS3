/* In Linux 2.6.26, part of list.h was broken out into rculist.h. */
#include <linux/list.h>
