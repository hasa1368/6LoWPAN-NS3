import sys
sys.path.insert(0, "../../build/examples/a")
from a import *

ADoA ()
ADoB (1)
a = ADoC ()
print(a)

