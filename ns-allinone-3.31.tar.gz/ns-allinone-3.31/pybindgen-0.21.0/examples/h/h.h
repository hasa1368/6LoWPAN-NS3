
class H
{
 public:
  void Do (void);
  class Inner
  {
  public:
    void Do (void);

    class MostInner
    {
    public:
      void Do (void);
    };
  };
};
